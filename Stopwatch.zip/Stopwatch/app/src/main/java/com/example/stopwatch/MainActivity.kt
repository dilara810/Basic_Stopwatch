package com.example.stopwatch

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import com.example.stopwatch.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var runnable : Runnable = Runnable{}
    private var handler : Handler = Handler(Looper.getMainLooper())
    private lateinit var sharedPreferences: SharedPreferences
    private var hour =0
    private var sec =0
    private var minute =0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        sharedPreferences = this.getSharedPreferences("com.example.stopwatch", Context.MODE_PRIVATE)
        hour = sharedPreferences.getInt("hour", 0)
        minute = sharedPreferences.getInt("minute", 0)
        sec = sharedPreferences.getInt("sec", 0)
        val formattedTime = String.format("%02d:%02d:%02d", hour, minute, sec)
        binding.textView.text = formattedTime


    }

    fun start(view : View){

        runnable = Runnable {
            if (sec<59){
                sec++
                val editor = sharedPreferences.edit()
                editor.putInt("sec", sec)
                editor.putInt("hour", hour)
                editor.putInt("minute", minute)
                editor.apply()

                val formattedTime = String.format("%02d:%02d:%02d", hour, minute, sec)
                binding.textView.text = formattedTime
            } else{
                sec =0
                minute++
                val editor = sharedPreferences.edit()
                editor.putInt("sec", sec)
                editor.putInt("hour", hour)
                editor.putInt("minute", minute)
                editor.apply()

                val formattedTime = String.format("%02d:%02d:%02d", hour, minute, sec)
                binding.textView.text = formattedTime
            }
            if(minute == 59){
                minute =0
                hour++
                val editor = sharedPreferences.edit()
                editor.putInt("sec", sec)
                editor.putInt("hour", hour)
                editor.putInt("minute", minute)
                editor.apply()

                val formattedTime = String.format("%02d:%02d:%02d", hour, minute, sec)
                binding.textView.text = formattedTime
            }

            handler.postDelayed(runnable,1000)
        }

       handler.post(runnable)
       binding.button7.isEnabled=false

    }

    fun reset(view :View){
        handler.removeCallbacks(runnable)
        hour =0
        minute=0
        sec=0
        val editor = sharedPreferences.edit()
        editor.putInt("sec", sec)
        editor.putInt("hour", hour)
        editor.putInt("minute", minute)
        editor.apply()
        val formattedTime = String.format("%02d:%02d:%02d", hour, minute, sec)
        binding.textView.text = formattedTime
        binding.button7.isEnabled=true
    }

    fun stop(view: View){
        handler.removeCallbacks(runnable)
        val editor = sharedPreferences.edit()
        editor.putInt("sec", sec)
        editor.putInt("hour", hour)
        editor.putInt("minute", minute)
        editor.apply()

        binding.button7.isEnabled=true

    }




}